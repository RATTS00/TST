$(() => {
    let isAksesGranted = false; 
    $('#aks').on('click', () => {
        $.ajax({
            url: 'client-akses.php',
            method: 'POST',
            data: { trackerUsed: true }
        })
        .done((response) => {
            let html = '';
            if (response.status === 'success') {
                isAksesGranted = true; 
                html = `<p>Status: ${response.akses.status}</p>`;
                html += `<p>Pesan: ${response.akses.pesan}</p>`;
            } else {
                html = `<p>Error: ${response.message}</p>`;
            }
            $('#output').html(html);

            $('#his').prop('disabled', !isAksesGranted);
        })
        .fail((xhr, status, error) => {
            $('#output').html(`<p>Error: ${error}</p>`);
        });
    });

    $('#his').on('click', () => {
        if (!isAksesGranted) {
            $('#output').html('<p>Silakan mengakses Sistem Tracker Olahraga terlebih dahulu.</p>');
            return; 
        }

        $.ajax({
            url: 'client-history.php',
            method: 'POST'
        })
        .done((response) => {
            let html = '';
            if (response.histories && response.histories.length > 0) {
                for (let h of response.histories) {
                    html += `<p>${h.date} - ${h.location} - ${h.attendants}</p>`;
                }
            } else {
                html = '<p>Tidak ada riwayat ditemukan.</p>';
            }
            $('#output').html(html);
        })
        .fail((xhr, status, error) => {
            $('#output').html(`<p>Error: ${error}</p>`);
        });
    });
});
