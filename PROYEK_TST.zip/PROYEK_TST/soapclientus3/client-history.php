<?php
//client-history.php
$wsdl = "http://localhost/PROYEK_TST/usecase3/server.php?wsdl";

$client = new SoapClient($wsdl);
try {
    $histories = $client->getHistories(); 
    $response = [
        'status' => 'success',
        'histories' => $histories 
    ];
} catch (SoapFault $e) {
    $response = [
        'status' => 'error',
        'message' => $e->getMessage()
    ];
}

header('Content-Type: application/json');

echo json_encode($response);